<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\{
    Cursos, EntidadesFormadoreas, Examen, Formadores, Pcategory, Tipo_De_Curso, Tipo_Maquina
};

class CursosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cursos = Cursos::orderBy('id','desc')->get();

        return view('admin.cursos.index',compact('cursos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $entidad=EntidadesFormadoreas::select('id','nombre')->get();
        $formador=Formadores::select('id','nombre')->get();
        $tipo_maquina=Tipo_Maquina::select('id','tipo_maquina')->get();
        $tipo_curso=Tipo_De_Curso::select('id','tipo_curso')->get();
        $examen_t=Examen::select('id','nombre')->where('tipo',2)->get();
        $examen_p=Examen::select('id','nombre')->where('tipo',2)->get();
        $formadors=Formadores::select('id','nombre')->get();
        $formadors2=Formadores::select('id','nombre')->get();
        $formadors3=Formadores::select('id','nombre')->get();
        $x =Cursos::select('curso')->orderBy('id','desc')->latest()->get();
        $course_code = $x[0]->curso +1;

//        dd($course_code);

//        dd($formador[0]->nombre);
        return view('admin.cursos.create',compact('entidad','course_code','formador','tipo_maquina','tipo_curso','examen_t','examen_p','formadors','formadors2','formadors3'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//dd($request);

        $cursos = new Cursos($request->except('_token','tipo_maquina'));
//        dd($cursos);

//        $cursos = new Cursos();

        if(!$request->formador_apoyo_2){
            $cursos->formador_apoyo_2 = 0;
        }
        $x =$request->input('tipo_maquina');



        for( $i=0 ; $i <= count($x)-1 ;$i++ ){
            if($i == 0){
                $cursos->tipo_maquina_1 = $x[$i];
//                dd($x[$i]);
                $cursos->tipo_maquina_2 = null;
                $cursos->tipo_maquina_3 = null;
                $cursos->tipo_maquina_4 = null;
            }elseif ($i == 1){
                $cursos->tipo_maquina_2 = $x[$i];
                $cursos->tipo_maquina_3 = null;
                $cursos->tipo_maquina_4 = null;
            }elseif ($i == 2){
                $cursos->tipo_maquina_3 = $x[$i];
                $cursos->tipo_maquina_4 = null;
            }elseif ($i == 3){
                $cursos->tipo_maquina_4 = $x[$i];
            }

        }



//        $cursos->curso = $request->curso;
//        $cursos->tipo_curso = $request->tipo_curso;
//        $cursos->codigo = $request->codigo;
//        $cursos->entidad = $request->entidad;
//        $cursos->formador = $request->formador;
//        $cursos->formador_apoyo_1 = $request->formador_apoyo_1;
//        $cursos->formador_apoyo_2 = $request->formador_apoyo_2;
//        $cursos->formador_apoyo_3 = $request->formador_apoyo_3;
//        $cursos->fecha_inicio = $request->fecha_inicio;
//        $cursos->direccion = $request->direccion;
//        $cursos->ciudad = $request->ciudad;
//        $cursos->provincia = $request->provincia;
//        $cursos->codigo_postal = $request->codigo_postal;
////        $cursos->examen-t = $request->examen-t;
////        $cursos->examen-p = $request->examen-p;
//        $cursos->fecha_alta = $request->fecha_alta;
//        $cursos->observaciones = $request->observaciones;
////        $cursos->publico-privado = $request->publico-privado;
//        $cursos->cerrado = $request->cerrado;
//        $cursos->estado = $request->estado;


        $asistentes_pdf = $request->file('asistentes_pdf');

        if($asistentes_pdf){
        $asistentes_pdf_path = $asistentes_pdf->store('Cursos/'.$request->codigo, 'public');
        $cursos->asistentes_pdf = $asistentes_pdf_path;
        }

        if ($cursos->save()) {

                return redirect()->route('admin.cursos')->with('success', 'Data added successfully');

               } else {

                return redirect()->route('admin.cursos.create')->with('error', 'Data failed to add');

               }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $cursos = Cursos::findOrFail($id);
        $entidad=EntidadesFormadoreas::select('id','nombre')->get();
        $formador=Formadores::select('id','nombre')->get();
        $tipo_maquina=Tipo_Maquina::select('id','tipo_maquina')->get();
        $tipo_curso=Tipo_De_Curso::select('id','tipo_curso')->get();
        $examen_t=Examen::select('id','nombre')->where('tipo',2)->get();
        $examen_p=Examen::select('id','nombre')->where('tipo',2)->get();
        $formadors=Formadores::select('id','nombre')->get();
        $formadors2=Formadores::select('id','nombre')->get();
        $formadors3=Formadores::select('id','nombre')->get();

        return view('admin.Cursos.edit',compact('cursos','entidad','formador','tipo_maquina','tipo_curso','examen_t','examen_p','formadors','formadors2','formadors3'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//        \Validator::make($request->all(), [
//            "category" => "required",
//            "desc" => "required"
//        ])->validate();

        $cursos = Cursos::findOrFail($id);
//        $Cursos->pcategory_id = $request->category;
//        $Cursos->name = $request->name;
//        $Cursos->client = $request->client;
//        $Cursos->desc = $request->desc;
//        $Cursos->date = $request->date;


        $new_cover = $request->file('cover');

        if($new_cover){
        if($cursos->cover && file_exists(storage_path('app/public/' . $cursos->cover))){
            \Storage::delete('public/'. $cursos->cover);
        }

        $new_cover_path = $new_cover->store('images/Cursos', 'public');

        $cursos->cover = $new_cover_path;

        }

        if ($cursos->save()) {

                return redirect()->route('admin.cursos')->with('success', 'Data updated successfully');

               } else {

                return redirect()->route('admin.cursos.edit')->with('error', 'Data failed to update');

               }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cursos = cursos::findOrFail($id);
        $cursos->delete();

        return redirect()->route('admin.cursos')->with('success', 'Data deleted successfully');
    }
}
